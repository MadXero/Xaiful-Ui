----------------------------------------------------------------------------
-- Copy this section of the file to a file called MyMedia.lua, and enter
-- your medias information, using the examples shown below.
----------------------------------------------------------------------------

local LSM = LibStub("LibSharedMedia-3.0")

-- START of the section that you should be editing
--
--    NB: any line beginning with "--" is ignored - so the lines
--    below are just comments!
--

--background:

--border:Gotham Narrow Ultra

--font:

LSM:Register("font", "itc-avant-garde-gothic-lt-medium", [[Interface\Addons\SharedMedia_MyMedia\font\itc-avant-garde-gothic-lt-medium.ttf]])

LSM:Register("font", "Gotham Narrow Ultra", [[Interface\Addons\SharedMedia_MyMedia\font\Gotham Narrow Ultra.ttf]])

--sound:

--statusbar:

-- END of the section that you should be editing