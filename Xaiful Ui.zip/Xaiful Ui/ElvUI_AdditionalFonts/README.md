# ElvUI_AdditionalFonts
Adds additional fonts to ElvUI.

https://www.curseforge.com/wow/addons/elvui-additional-fonts
